package com.example.storyhub.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.storyhub.R;
import com.example.storyhub.models.Chapter;

import java.util.List;

public class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.ViewHolder> {

    private List<Chapter> chapterList;
    private OnChapterClickListener listener;

    public interface OnChapterClickListener {
        void onChapterClick(Chapter chapter);
    }

    public ChapterAdapter(List<Chapter> chapterList, OnChapterClickListener listener) {
        this.chapterList = chapterList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chapter, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Chapter chapter = chapterList.get(position);

        holder.txtChapterNumber.setText("Chapter " + chapter.chapterNumber);
        holder.txtChapterTitle.setText(chapter.title);
        holder.txtPublishedAt.setText(chapter.publishedAt != null ? chapter.publishedAt : "");

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onChapterClick(chapter);
        });
    }

    @Override
    public int getItemCount() {
        return chapterList != null ? chapterList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtChapterNumber, txtChapterTitle, txtPublishedAt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtChapterNumber = itemView.findViewById(R.id.txtChapterNumber);
            txtChapterTitle = itemView.findViewById(R.id.txtChapterTitle);
            txtPublishedAt = itemView.findViewById(R.id.txtPublishedAt);
        }
    }
}