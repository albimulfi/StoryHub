package com.example.storyhub.models;

import com.google.gson.annotations.SerializedName;

public class Art {
    public int id;
    public String title;
    public String nametag;
    public String category;
    public String status;
    public String synopsis;
    public String tagline;

    @SerializedName("cover_img")
    public String coverImg;

    @SerializedName("banner_img")
    public String bannerImg;

    @SerializedName("authorOrDev")
    public String authorOrDev;

    public String artist;

    @SerializedName("published_at")
    public String publishedAt;

    @SerializedName("jumlah_chapter")
    public Integer jumlahChapter;

    @SerializedName("rata2_rating")
    public double rata2Rating;

    @SerializedName("total_reviews")
    public int totalReviews;

    @SerializedName("rata2_rating_ch")
    public double rata2RatingCh;

    @SerializedName("total_reviews_ch")
    public int totalReviewsCh;

    @SerializedName("rata2_rating_user")
    public double rata2RatingUser;

    @SerializedName("total_reviews_user")
    public int totalReviewsUser;
}