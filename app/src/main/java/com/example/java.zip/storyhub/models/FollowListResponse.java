package com.example.storyhub.models;

import java.util.List;

public class FollowListResponse {
    public List<User> follower;
    public List<User> following;
}