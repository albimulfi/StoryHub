package com.example.storyhub.models;

public class IsFollowingResponse {
    public boolean isFollowing;
    public boolean isFollower;
}