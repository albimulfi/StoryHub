package com.example.storyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.CreateArtRequest;
import com.example.storyhub.models.CreateArtResponse;
import com.example.storyhub.utils.TokenManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateNovelActivity extends AppCompatActivity {

    ImageView btnBack;
    EditText etTitle, etTagline, etSynopsis, etCoverImg, etBannerImg;
    Spinner spinnerStatus;
    Button btnNext, btnDraft;
    ProgressBar progressBar;

    TokenManager tokenManager;
    ArtApiService artService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_novel);

        tokenManager = new TokenManager(this);
        artService = RetrofitClient.getAuthInstance(tokenManager).create(ArtApiService.class);

        initViews();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        etTitle = findViewById(R.id.etTitle);
        etTagline = findViewById(R.id.etTagline);
        etSynopsis = findViewById(R.id.etSynopsis);
        etCoverImg = findViewById(R.id.etCoverImg);
        etBannerImg = findViewById(R.id.etBannerImg);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        btnNext = findViewById(R.id.btnNext);
        btnDraft = findViewById(R.id.btnDraft);
        progressBar = findViewById(R.id.progressBar);

        String[] statusOptions = {"Ongoing", "Completed", "Hiatus"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, statusOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());

        btnNext.setOnClickListener(v -> createNovel("Published"));
        btnDraft.setOnClickListener(v -> createNovel("Draft"));
    }

    private void createNovel(String isPublished) {
        String title = etTitle.getText().toString().trim();
        String tagline = etTagline.getText().toString().trim();
        String synopsis = etSynopsis.getText().toString().trim();
        String coverImg = etCoverImg.getText().toString().trim();
        String bannerImg = etBannerImg.getText().toString().trim();
        String status = spinnerStatus.getSelectedItem().toString();

        if (title.isEmpty() || tagline.isEmpty() || synopsis.isEmpty()
                || coverImg.isEmpty() || bannerImg.isEmpty()) {
            Toast.makeText(this, "Semua field harus diisi.", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnNext.setEnabled(false);
        btnDraft.setEnabled(false);

        CreateArtRequest request = new CreateArtRequest(
                isPublished, title, coverImg, bannerImg,
                status, "Novel", tagline, synopsis
        );

        artService.createArt(request).enqueue(new Callback<CreateArtResponse>() {
            @Override
            public void onResponse(Call<CreateArtResponse> call,
                                   Response<CreateArtResponse> response) {
                progressBar.setVisibility(View.GONE);
                btnNext.setEnabled(true);
                btnDraft.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    int artId = response.body().artId;

                    Toast.makeText(CreateNovelActivity.this,
                            "Novel berhasil dibuat!", Toast.LENGTH_SHORT).show();

                    if (isPublished.equals("Published")) {
                        // langsung ke post chapter
                        Intent intent = new Intent(CreateNovelActivity.this,
                                CreateChapterActivity.class);
                        intent.putExtra("art_id", artId);
                        intent.putExtra("art_title", title);
                        startActivity(intent);
                        finish();
                    } else {
                        // kalau draft
                        finish();
                    }
                } else {
                    Toast.makeText(CreateNovelActivity.this,
                            "Gagal membuat novel.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CreateArtResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                btnNext.setEnabled(true);
                btnDraft.setEnabled(true);
                Toast.makeText(CreateNovelActivity.this,
                        "Gagal terhubung ke server.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}