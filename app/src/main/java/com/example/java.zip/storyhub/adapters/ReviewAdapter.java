package com.example.storyhub.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.storyhub.R;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.Review;

import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ViewHolder> {

    private Context context;
    private List<Review> reviewList;

    public ReviewAdapter(Context context, List<Review> reviewList) {
        this.context = context;
        this.reviewList = reviewList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_review, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Review review = reviewList.get(position);

        holder.txtUsername.setText(review.username);
        holder.txtRating.setText("⭐ " + review.rating + "/10");
        holder.txtKomentar.setText(review.komentar);
        holder.txtLikes.setText("👍 " + review.totalLikes);

        Glide.with(context)
                .load(RetrofitClient.IMAGE_BASE_URL + review.profileImg)
                .placeholder(R.drawable.storyhub_logo)
                .circleCrop()
                .into(holder.imgProfile);
    }

    @Override
    public int getItemCount() {
        return reviewList != null ? reviewList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProfile;
        TextView txtUsername, txtRating, txtKomentar, txtLikes;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProfile = itemView.findViewById(R.id.imgProfile);
            txtUsername = itemView.findViewById(R.id.txtUsername);
            txtRating = itemView.findViewById(R.id.txtRating);
            txtKomentar = itemView.findViewById(R.id.txtKomentar);
            txtLikes = itemView.findViewById(R.id.txtLikes);
        }
    }
}