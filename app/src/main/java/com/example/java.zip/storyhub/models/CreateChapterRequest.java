package com.example.storyhub.models;

import com.google.gson.annotations.SerializedName;

public class CreateChapterRequest {
    public String title;

    @SerializedName("isi_chapter")
    public String isiChapter;

    public CreateChapterRequest(String title, String isiChapter) {
        this.title = title;
        this.isiChapter = isiChapter;
    }
}