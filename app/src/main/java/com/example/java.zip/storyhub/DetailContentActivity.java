package com.example.storyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.storyhub.adapters.ChapterAdapter;
import com.example.storyhub.adapters.ReviewAdapter;
import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.ReviewApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.Art;
import com.example.storyhub.models.ArtDetailResponse;
import com.example.storyhub.models.ArtGenreTagMoodResponse;
import com.example.storyhub.models.ArtResponse;
import com.example.storyhub.models.BookmarkResponse;
import com.example.storyhub.models.Chapter;
import com.example.storyhub.models.ChapterResponse;
import com.example.storyhub.models.MessageResponse;
import com.example.storyhub.models.Review;
import com.example.storyhub.models.ReviewRequest;
import com.example.storyhub.models.ReviewResponse;
import com.example.storyhub.utils.TokenManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailContentActivity extends AppCompatActivity {

    ImageView imgBanner, imgCover, btnBack, btnBookmark;
    TextView txtTitle, txtTagline, txtRating, txtReviewers,
            txtChapters, txtSynopsis, txtAuthor, txtArtist,
            txtStatus, txtPublished, txtCategory;
    Button btnContinueReading, btnTabOverview, btnTabChapters, btnTabReviews;
    LinearLayout layoutOverview, layoutChapters, layoutReviews;
    LinearLayout containerGenres, containerTags, containerMoods;
    RecyclerView recyclerChapters, recyclerReviews;
    Button btnAddReview;

    int artId;
    Art currentArt;
    boolean isBookmarked = false;
    TokenManager tokenManager;
    ArtApiService artService;
    ReviewApiService reviewService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_content);

        tokenManager = new TokenManager(this);
        artId = getIntent().getIntExtra("art_id", -1);

        if (artId == -1) {
            finish();
            return;
        }

        artService = RetrofitClient.getAuthInstance(tokenManager).create(ArtApiService.class);
        reviewService = RetrofitClient.getAuthInstance(tokenManager).create(ReviewApiService.class);

        initViews();
        setupTabs();
        loadArtDetail();
        loadGenreTagMood();
        loadChapters();
        loadReviews();
    }

    private void initViews() {
        imgBanner = findViewById(R.id.imgBanner);
        imgCover = findViewById(R.id.imgCover);
        btnBack = findViewById(R.id.btnBack);
        btnBookmark = findViewById(R.id.btnBookmark);
        txtTitle = findViewById(R.id.txtTitle);
        txtTagline = findViewById(R.id.txtTagline);
        txtRating = findViewById(R.id.txtRating);
        txtReviewers = findViewById(R.id.txtReviewers);
        txtChapters = findViewById(R.id.txtChapters);
        txtSynopsis = findViewById(R.id.txtSynopsis);
        txtAuthor = findViewById(R.id.txtAuthor);
        txtArtist = findViewById(R.id.txtArtist);
        txtStatus = findViewById(R.id.txtStatus);
        txtPublished = findViewById(R.id.txtPublished);
        txtCategory = findViewById(R.id.txtCategory);

        containerGenres = findViewById(R.id.containerGenres);
        containerTags = findViewById(R.id.containerTags);
        containerMoods = findViewById(R.id.containerMoods);

        btnContinueReading = findViewById(R.id.btnContinueReading);
        btnTabOverview = findViewById(R.id.btnTabOverview);
        btnTabChapters = findViewById(R.id.btnTabChapters);
        btnTabReviews = findViewById(R.id.btnTabReviews);
        layoutOverview = findViewById(R.id.layoutOverview);
        layoutChapters = findViewById(R.id.layoutChapters);
        layoutReviews = findViewById(R.id.layoutReviews);
        recyclerChapters = findViewById(R.id.recyclerChapters);
        recyclerReviews = findViewById(R.id.recyclerReviews);
        btnAddReview = findViewById(R.id.btnAddReview);

        recyclerChapters.setLayoutManager(new LinearLayoutManager(this));
        recyclerChapters.setNestedScrollingEnabled(false);

        recyclerReviews.setLayoutManager(new LinearLayoutManager(this));
        recyclerReviews.setNestedScrollingEnabled(false);

        btnBack.setOnClickListener(v -> finish());

        btnBookmark.setOnClickListener(v -> toggleBookmark());

        btnAddReview.setOnClickListener(v -> showReviewDialog());

        if (!tokenManager.isLoggedIn()) {
            btnAddReview.setVisibility(View.GONE);
        }
    }

    private void setupTabs() {
        showTab("overview");

        btnTabOverview.setOnClickListener(v -> showTab("overview"));
        btnTabChapters.setOnClickListener(v -> showTab("chapters"));
        btnTabReviews.setOnClickListener(v -> showTab("reviews"));
    }

    private void showTab(String tab) {
        layoutOverview.setVisibility(tab.equals("overview") ? View.VISIBLE : View.GONE);
        layoutChapters.setVisibility(tab.equals("chapters") ? View.VISIBLE : View.GONE);
        layoutReviews.setVisibility(tab.equals("reviews") ? View.VISIBLE : View.GONE);

        int active = getResources().getColor(R.color.primary);
        int inactive = getResources().getColor(R.color.black);

        btnTabOverview.setTextColor(tab.equals("overview") ? active : inactive);
        btnTabChapters.setTextColor(tab.equals("chapters") ? active : inactive);
        btnTabReviews.setTextColor(tab.equals("reviews") ? active : inactive);
    }

    private void loadArtDetail() {
        artService.getArtById(artId).enqueue(new Callback<ArtDetailResponse>() {
            @Override
            public void onResponse(Call<ArtDetailResponse> call, Response<ArtDetailResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                    Art art = response.body().data;
                    currentArt = art;

                    txtTitle.setText(art.title);
                    txtTagline.setText(art.tagline);
                    txtCategory.setText(art.category);
                    txtRating.setText("⭐ " + String.format("%.1f", art.rata2Rating));
                    txtReviewers.setText("👥 " + art.totalReviews + " Reviews");
                    txtChapters.setText("📖 " + (art.jumlahChapter != null ? art.jumlahChapter : 0) + " Chapters");
                    txtSynopsis.setText(art.synopsis);
                    txtAuthor.setText(art.authorOrDev);
                    txtArtist.setText(art.artist != null ? art.artist : "-");
                    txtStatus.setText(art.status);
                    txtPublished.setText(art.publishedAt);

                    Glide.with(DetailContentActivity.this)
                            .load(RetrofitClient.IMAGE_BASE_URL + art.bannerImg)
                            .placeholder(R.drawable.storyhub_logo)
                            .into(imgBanner);

                    Glide.with(DetailContentActivity.this)
                            .load(RetrofitClient.IMAGE_BASE_URL + art.coverImg)
                            .placeholder(R.drawable.storyhub_logo)
                            .into(imgCover);

                } else {
                    Toast.makeText(DetailContentActivity.this,
                            "Art tidak ditemukan.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onFailure(Call<ArtDetailResponse> call, Throwable t) {
                Toast.makeText(DetailContentActivity.this,
                        "Gagal load data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadGenreTagMood() {
        // genre2
        artService.getArtGenres(artId).enqueue(new Callback<ArtGenreTagMoodResponse>() {
            @Override
            public void onResponse(Call<ArtGenreTagMoodResponse> call,
                                   Response<ArtGenreTagMoodResponse> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().data != null) {
                    containerGenres.removeAllViews();
                    for (ArtGenreTagMoodResponse.Item item : response.body().data) {
                        addChip(containerGenres, item.genre);
                    }
                }
            }
            @Override
            public void onFailure(Call<ArtGenreTagMoodResponse> call, Throwable t) {}
        });

        // tag2
        artService.getArtTags(artId).enqueue(new Callback<ArtGenreTagMoodResponse>() {
            @Override
            public void onResponse(Call<ArtGenreTagMoodResponse> call,
                                   Response<ArtGenreTagMoodResponse> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().data != null) {
                    if (containerTags != null) containerTags.removeAllViews();
                    for (ArtGenreTagMoodResponse.Item item : response.body().data) {
                        if (containerTags != null) addChip(containerTags, "#" + item.tag);
                    }
                }
            }
            @Override
            public void onFailure(Call<ArtGenreTagMoodResponse> call, Throwable t) {}
        });

        // mood2
        artService.getArtMoods(artId).enqueue(new Callback<ArtGenreTagMoodResponse>() {
            @Override
            public void onResponse(Call<ArtGenreTagMoodResponse> call,
                                   Response<ArtGenreTagMoodResponse> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().data != null) {
                    if (containerMoods != null) containerMoods.removeAllViews();
                    for (ArtGenreTagMoodResponse.Item item : response.body().data) {
                        if (containerMoods != null) addChip(containerMoods, item.mood);
                    }
                }
            }
            @Override
            public void onFailure(Call<ArtGenreTagMoodResponse> call, Throwable t) {}
        });
    }

    private void addChip(LinearLayout container, String text) {
        if (text == null || text.isEmpty()) return;

        TextView chip = new TextView(this);
        chip.setText(text);
        chip.setTextSize(12f);
        chip.setTextColor(getResources().getColor(R.color.primary));
        chip.setBackgroundResource(R.drawable.chip_background);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMarginEnd(8);
        chip.setPadding(16, 8, 16, 8);
        chip.setLayoutParams(params);

        container.addView(chip);
    }

    private void loadChapters() {
        artService.getChapters(artId).enqueue(new Callback<ChapterResponse>() {
            @Override
            public void onResponse(Call<ChapterResponse> call, Response<ChapterResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                    List<Chapter> chapters = response.body().data;

                    if (chapters != null && !chapters.isEmpty()) {
                        ChapterAdapter adapter = new ChapterAdapter(chapters, chapter -> {
                            Intent intent = new Intent(DetailContentActivity.this, ChapterReaderActivity.class);
                            intent.putExtra("art_id", artId);
                            intent.putExtra("chapter_number", chapter.chapterNumber);
                            intent.putExtra("chapter_id", chapter.id);
                            startActivity(intent);
                        });
                        recyclerChapters.setAdapter(adapter);

                        if (txtChapters != null) {
                            txtChapters.setText("📖 " + chapters.size() + " Chapters");
                        }

                        Chapter firstChapter = chapters.get(0);
                        btnContinueReading.setOnClickListener(v -> {
                            Intent intent = new Intent(DetailContentActivity.this, ChapterReaderActivity.class);
                            intent.putExtra("art_id", artId);
                            intent.putExtra("chapter_number", firstChapter.chapterNumber);
                            intent.putExtra("chapter_id", firstChapter.id);
                            startActivity(intent);
                        });
                    }
                }
            }

            @Override
            public void onFailure(Call<ChapterResponse> call, Throwable t) {
                Toast.makeText(DetailContentActivity.this, "Gagal load chapters.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadReviews() {
        reviewService.getReviews("arts", artId).enqueue(new Callback<ReviewResponse>() {
            @Override
            public void onResponse(Call<ReviewResponse> call, Response<ReviewResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                    List<Review> reviews = response.body().data;

                    if (reviews != null && !reviews.isEmpty()) {
                        ReviewAdapter adapter = new ReviewAdapter(DetailContentActivity.this, reviews);
                        recyclerReviews.setAdapter(adapter);

                        txtReviewers.setText("👥 " + response.body().totalReviews + " Reviews");
                    } else {
                        TextView empty = new TextView(DetailContentActivity.this);
                        empty.setText("Belum ada review. Jadilah yang pertama!");
                        empty.setPadding(32, 16, 32, 16);
                        layoutReviews.addView(empty, 0);
                    }
                }
            }

            @Override
            public void onFailure(Call<ReviewResponse> call, Throwable t) {}
        });
    }

    private void toggleBookmark() {
        if (!tokenManager.isLoggedIn()) {
            Toast.makeText(this, "Login dulu untuk bookmark.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isBookmarked) {
            artService.removeBookmarkArt(artId).enqueue(new Callback<BookmarkResponse>() {
                @Override
                public void onResponse(Call<BookmarkResponse> call, Response<BookmarkResponse> response) {
                    if (response.isSuccessful()) {
                        isBookmarked = false;
                        btnBookmark.setColorFilter(
                                getResources().getColor(android.R.color.white));
                        Toast.makeText(DetailContentActivity.this,
                                "Dihapus dari bookmark.", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<BookmarkResponse> call, Throwable t) {}
            });
        } else {
            artService.addBookmarkArt(artId).enqueue(new Callback<BookmarkResponse>() {
                @Override
                public void onResponse(Call<BookmarkResponse> call, Response<BookmarkResponse> response) {
                    if (response.isSuccessful()) {
                        isBookmarked = true;
                        btnBookmark.setColorFilter(
                                getResources().getColor(R.color.primary));
                        Toast.makeText(DetailContentActivity.this,
                                "Ditambah ke bookmark!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<BookmarkResponse> call, Throwable t) {}
            });
        }
    }

    private void showReviewDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Tulis Review");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_review, null);
        builder.setView(dialogView);

        RatingBar ratingBarTop = dialogView.findViewById(R.id.ratingBarTop);
        RatingBar ratingBarBottom = dialogView.findViewById(R.id.ratingBarBottom);
        EditText etKomentar = dialogView.findViewById(R.id.etKomentar);

        ratingBarTop.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {

            if (!fromUser) return;

            ratingBarBottom.setRating(0);
        });

        ratingBarBottom.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {

            if (!fromUser) return;

            if (rating > 0) {
                ratingBarTop.setRating(5);
            }
        });

        builder.setPositiveButton("Kirim", (dialog, which) -> {
            int rating = (int) (
                    ratingBarTop.getRating() + ratingBarBottom.getRating()
            );
            String komentar = etKomentar.getText().toString().trim();

            if (rating == 0) {
                Toast.makeText(this, "Rating harus diisi (1-10).", Toast.LENGTH_SHORT).show();
                return;
            }

            reviewService.postReview("arts", artId, new ReviewRequest(rating, komentar))
                    .enqueue(new Callback<MessageResponse>() {
                        @Override
                        public void onResponse(Call<MessageResponse> call, Response<MessageResponse> response) {
                            if (response.isSuccessful()) {
                                Toast.makeText(DetailContentActivity.this,
                                        "Review berhasil dikirim!", Toast.LENGTH_SHORT).show();
                                loadReviews();
                            } else if (response.code() == 403) {
                                Toast.makeText(DetailContentActivity.this,
                                        "Kamu sudah pernah review ini.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<MessageResponse> call, Throwable t) {}
                    });
        });

        builder.setNegativeButton("Batal", null);
        builder.show();
    }

    public void setArtData(Art art) {
        this.currentArt = art;

        txtTitle.setText(art.title);
        txtTagline.setText(art.tagline);
        txtCategory.setText(art.category);
        txtRating.setText("⭐ " + String.format("%.1f", art.rata2Rating));
        txtReviewers.setText("👥 " + art.totalReviews);
        txtChapters.setText("📖 " + (art.jumlahChapter != null ? art.jumlahChapter : 0) + " Chapters");
        txtSynopsis.setText(art.synopsis);
        txtAuthor.setText(art.authorOrDev);
        txtArtist.setText(art.artist != null ? art.artist : "-");
        txtStatus.setText(art.status);
        txtPublished.setText(art.publishedAt);

        Glide.with(this)
                .load(RetrofitClient.IMAGE_BASE_URL + art.bannerImg)
                .placeholder(R.drawable.storyhub_logo)
                .into(imgBanner);

        Glide.with(this)
                .load(RetrofitClient.IMAGE_BASE_URL + art.coverImg)
                .placeholder(R.drawable.storyhub_logo)
                .into(imgCover);
    }
}