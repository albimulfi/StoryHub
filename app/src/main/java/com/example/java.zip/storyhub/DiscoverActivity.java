package com.example.storyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.storyhub.adapters.ArtAdapter;
import com.example.storyhub.adapters.ChapterListAdapter;
import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.FilterApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.ArtResponse;
import com.example.storyhub.models.ChapterListResponse;
import com.example.storyhub.models.Genre;
import com.example.storyhub.models.GenreResponse;
import com.example.storyhub.models.Mood;
import com.example.storyhub.models.MoodResponse;
import com.example.storyhub.models.Tag;
import com.example.storyhub.models.TagResponse;
import com.example.storyhub.utils.TokenManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DiscoverActivity extends AppCompatActivity {

    // nav bar
    LinearLayout navHome, navDiscover, navBookmark, navProfile;

    // tab
    Button btnTabArt, btnTabChapter;
    RecyclerView recyclerArts, recyclerChapters;
    ArtAdapter artAdapter;
    ChapterListAdapter chapterAdapter;

    // filter panel
    LinearLayout layoutFilterPanel;
    Button btnOpenFilter, btnApplyFilter, btnResetFilter;

    // filter category
    CheckBox cbBook, cbNovel, cbManhwa, cbManga, cbComic,
            cbGame, cbVisualNovel, cbStoryGame;

    // filter sort
    RadioGroup radioSort, radioOrder;
    RadioButton rbSortTitle, rbSortRatingArt, rbSortReviewersArt,
            rbSortRatingCh, rbSortChapters, rbSortPublished;
    RadioButton rbOrderAsc, rbOrderDesc;

    // filter genre, tag, mood
    com.google.android.flexbox.FlexboxLayout containerFilterGenre, containerFilterTag, containerFilterMood;

    // perhalamanan
    LinearLayout layoutPagination;
    Button btnPrevPage, btnNextPage;
    TextView txtPageInfo;

    // state pilihan (selected)
    int currentPage = 1;
    int totalPages = 1;
    String currentTab = "art";
    List<String> selectedGenres = new ArrayList<>();
    List<String> selectedTags = new ArrayList<>();
    List<String> selectedMoods = new ArrayList<>();
    List<String> selectedCategories = new ArrayList<>();
    String selectedSort = "title";
    String selectedOrder = "ASC";
    boolean filterPanelOpen = false;

    TokenManager tokenManager;
    ArtApiService artService;
    FilterApiService filterService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);

        tokenManager = new TokenManager(this);
        artService = RetrofitClient.getAuthInstance(tokenManager).create(ArtApiService.class);
        filterService = RetrofitClient.getInstance().create(FilterApiService.class);

        initViews();
        setupNav();
        setupTabs();
        loadFilterOptions();
        loadArts();
    }

    private void initViews() {
        navHome = findViewById(R.id.navHome);
        navDiscover = findViewById(R.id.navDiscover);
        navBookmark = findViewById(R.id.navBookmark);
        navProfile = findViewById(R.id.navProfile);

        btnTabArt = findViewById(R.id.btnTabArt);
        btnTabChapter = findViewById(R.id.btnTabChapter);

        recyclerArts = findViewById(R.id.recyclerArts);

        if (recyclerArts != null) {
            recyclerArts.setLayoutManager(new LinearLayoutManager(this));
        }

        recyclerChapters = findViewById(R.id.recyclerChapters);

        if (recyclerChapters != null) {
            recyclerChapters.setLayoutManager(new LinearLayoutManager(this));
        }

        layoutFilterPanel = findViewById(R.id.layoutFilterPanel);
        btnOpenFilter = findViewById(R.id.btnOpenFilter);
        btnApplyFilter = findViewById(R.id.btnApplyFilter);
        btnResetFilter = findViewById(R.id.btnResetFilter);

        cbBook = findViewById(R.id.cbBook);
        cbNovel = findViewById(R.id.cbNovel);
        cbManhwa = findViewById(R.id.cbManhwa);
        cbManga = findViewById(R.id.cbManga);
        cbComic = findViewById(R.id.cbComic);
        cbGame = findViewById(R.id.cbGame);
        cbVisualNovel = findViewById(R.id.cbVisualNovel);
        cbStoryGame = findViewById(R.id.cbStoryGame);

        radioSort = findViewById(R.id.radioSort);
        radioOrder = findViewById(R.id.radioOrder);
        rbSortTitle = findViewById(R.id.rbSortTitle);
        rbSortRatingArt = findViewById(R.id.rbSortRatingArt);
        rbSortReviewersArt = findViewById(R.id.rbSortReviewersArt);
        rbSortRatingCh = findViewById(R.id.rbSortRatingCh);
        rbSortChapters = findViewById(R.id.rbSortChapters);
        rbSortPublished = findViewById(R.id.rbSortPublished);
        rbOrderAsc = findViewById(R.id.rbOrderAsc);
        rbOrderDesc = findViewById(R.id.rbOrderDesc);

        containerFilterGenre = findViewById(R.id.containerFilterGenre);
        containerFilterTag = findViewById(R.id.containerFilterTag);
        containerFilterMood = findViewById(R.id.containerFilterMood);

        layoutPagination = findViewById(R.id.layoutPagination);
        btnPrevPage = findViewById(R.id.btnPrevPage);
        btnNextPage = findViewById(R.id.btnNextPage);
        txtPageInfo = findViewById(R.id.txtPageInfo);

        btnOpenFilter.setOnClickListener(v -> toggleFilterPanel());

        btnApplyFilter.setOnClickListener(v -> {
            collectFilters();
            currentPage = 1;
            toggleFilterPanel();
            if (currentTab.equals("art")) loadArts();
            else loadChapters();
        });

        btnResetFilter.setOnClickListener(v -> resetFilters());

        btnPrevPage.setOnClickListener(v -> {
            if (currentPage > 1) {
                currentPage--;
                if (currentTab.equals("art")) loadArts();
                else loadChapters();
            }
        });

        btnNextPage.setOnClickListener(v -> {
            if (currentPage < totalPages) {
                currentPage++;
                if (currentTab.equals("art")) loadArts();
                else loadChapters();
            }
        });

        // search bar
        findViewById(R.id.searchBar).setOnClickListener(v ->
                startActivity(new Intent(this, SearchActivity.class)));
    }

    private void toggleFilterPanel() {
        filterPanelOpen = !filterPanelOpen;
        layoutFilterPanel.setVisibility(filterPanelOpen ? View.VISIBLE : View.GONE);
        btnOpenFilter.setText(filterPanelOpen ? "✕ Tutup Filter" : "⚙ Filter & Sort");
    }

    private void setupTabs() {
        btnTabArt.setOnClickListener(v -> {
            currentTab = "art";
            currentPage = 1;
            recyclerArts.setVisibility(View.VISIBLE);
            recyclerChapters.setVisibility(View.GONE);
            btnTabArt.setTextColor(getResources().getColor(R.color.primary));
            btnTabChapter.setTextColor(getResources().getColor(R.color.black));
            loadArts();
        });

        btnTabChapter.setOnClickListener(v -> {
            currentTab = "chapter";
            currentPage = 1;
            recyclerArts.setVisibility(View.GONE);
            recyclerChapters.setVisibility(View.VISIBLE);
            btnTabArt.setTextColor(getResources().getColor(R.color.black));
            btnTabChapter.setTextColor(getResources().getColor(R.color.primary));
            loadChapters();
        });
    }

    private void setupNav() {
        navHome.setOnClickListener(v ->
                startActivity(new Intent(this, HomeActivity.class)));

        // navBookmark.setOnClickListener(v ->
                // startActivity(new Intent(this, BookmarkActivity.class)));

        navBookmark.setOnClickListener(v ->
                startActivity(new Intent(this, MyListActivity.class)));

        navProfile.setOnClickListener(v ->
                startActivity(new Intent(this, ProfileActivity.class)));
    }

    private void loadFilterOptions() {
        filterService.getGenres().enqueue(new Callback<GenreResponse>() {
            @Override
            public void onResponse(Call<GenreResponse> call, Response<GenreResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<String> items = new ArrayList<>();
                    for (Genre g : response.body().data) items.add(g.genre);
                    buildFilterChips(containerFilterGenre, items, selectedGenres);
                }
            }
            @Override
            public void onFailure(Call<GenreResponse> call, Throwable t) {}
        });

        filterService.getTags().enqueue(new Callback<TagResponse>() {
            @Override
            public void onResponse(Call<TagResponse> call, Response<TagResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<String> items = new ArrayList<>();
                    for (Tag t : response.body().data) items.add(t.tag);
                    buildFilterChips(containerFilterTag, items, selectedTags);
                }
            }
            @Override
            public void onFailure(Call<TagResponse> call, Throwable t) {}
        });

        filterService.getMoods().enqueue(new Callback<MoodResponse>() {
            @Override
            public void onResponse(Call<MoodResponse> call, Response<MoodResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<String> items = new ArrayList<>();
                    for (Mood m : response.body().data) items.add(m.mood);
                    buildFilterChips(containerFilterMood, items, selectedMoods);
                }
            }
            @Override
            public void onFailure(Call<MoodResponse> call, Throwable t) {}
        });
    }

    private void buildFilterChips(com.google.android.flexbox.FlexboxLayout container,
                                  List<String> items, List<String> selectedList) {
        runOnUiThread(() -> {
            container.removeAllViews();
            for (String item : items) {
                Button chip = new Button(this);
                chip.setText(item);
                chip.setTextSize(12f);
                chip.setBackgroundResource(R.drawable.chip_background);
                chip.setTextColor(getResources().getColor(R.color.primary));

                com.google.android.flexbox.FlexboxLayout.LayoutParams params =
                        new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT,
                                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 0, 12, 12);
                chip.setLayoutParams(params);

                chip.setOnClickListener(v -> {
                    if (selectedList.contains(item)) {
                        selectedList.remove(item);
                        chip.setBackgroundResource(R.drawable.chip_background);
                        chip.setTextColor(getResources().getColor(R.color.primary));
                    } else {
                        selectedList.add(item);
                        chip.setBackgroundResource(R.drawable.button_gradient);
                        chip.setTextColor(getResources().getColor(R.color.white));
                    }
                });

                container.addView(chip);
            }
        });
    }

    private void collectFilters() {
        selectedCategories.clear();
        if (cbBook != null && cbBook.isChecked()) selectedCategories.add("Book");
        if (cbNovel != null && cbNovel.isChecked()) selectedCategories.add("Novel");
        if (cbManhwa != null && cbManhwa.isChecked()) selectedCategories.add("Manhwa");
        if (cbManga != null && cbManga.isChecked()) selectedCategories.add("Manga");
        if (cbComic != null && cbComic.isChecked()) selectedCategories.add("Comic");
        if (cbGame != null && cbGame.isChecked()) selectedCategories.add("Game");
        if (cbVisualNovel != null && cbVisualNovel.isChecked()) selectedCategories.add("Visual Novel");
        if (cbStoryGame != null && cbStoryGame.isChecked()) selectedCategories.add("Story Game");

        int sortId = radioSort.getCheckedRadioButtonId();
        if (sortId == R.id.rbSortTitle) selectedSort = "title";
        else if (sortId == R.id.rbSortRatingArt) selectedSort = "ratingArt";
        else if (sortId == R.id.rbSortReviewersArt) selectedSort = "reviewersArt";
        else if (sortId == R.id.rbSortRatingCh) selectedSort = "ratingChapter";
        else if (sortId == R.id.rbSortChapters) selectedSort = "chapters";
        else if (sortId == R.id.rbSortPublished) selectedSort = "published";

        int orderId = radioOrder.getCheckedRadioButtonId();
        selectedOrder = (orderId == R.id.rbOrderDesc) ? "DESC" : "ASC";
    }

    private void resetFilters() {
        selectedCategories.clear();
        selectedGenres.clear();
        selectedTags.clear();
        selectedMoods.clear();
        selectedSort = "title";
        selectedOrder = "ASC";

        cbBook.setChecked(false); cbNovel.setChecked(false);
        cbManhwa.setChecked(false); cbManga.setChecked(false);
        cbComic.setChecked(false); cbGame.setChecked(false);
        cbVisualNovel.setChecked(false); cbStoryGame.setChecked(false);
        rbSortTitle.setChecked(true);
        rbOrderAsc.setChecked(true);

        resetChips(containerFilterGenre);
        resetChips(containerFilterTag);
        resetChips(containerFilterMood);

        currentPage = 1;
        if (currentTab.equals("art")) loadArts();
        else loadChapters();
    }

    private void resetChips(com.google.android.flexbox.FlexboxLayout container) {
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof Button) {
                child.setBackgroundResource(R.drawable.chip_background);
                ((Button) child).setTextColor(getResources().getColor(R.color.primary));
            }
        }
    }

    private void loadArts() {
        String category = selectedCategories.isEmpty() ? null :
                String.join(",", selectedCategories);
        String genre = selectedGenres.isEmpty() ? null :
                String.join(",", selectedGenres);
        String tag = selectedTags.isEmpty() ? null :
                String.join(",", selectedTags);
        String mood = selectedMoods.isEmpty() ? null :
                String.join(",", selectedMoods);

        artService.getArts(currentPage, 20, category, genre, tag, mood, selectedSort, selectedOrder)
                .enqueue(new Callback<ArtResponse>() {
                    @Override
                    public void onResponse(Call<ArtResponse> call, Response<ArtResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if (response.body().meta != null) {
                                totalPages = response.body().meta.total_pages;
                            }

                            updatePagination();

                            artAdapter = new ArtAdapter(DiscoverActivity.this,
                                    response.body().data, art -> {
                                Intent intent = new Intent(DiscoverActivity.this,
                                        DetailContentActivity.class);
                                intent.putExtra("art_id", art.id);
                                startActivity(intent);
                            });
                            recyclerArts.setAdapter(artAdapter);
                        }
                    }

                    @Override
                    public void onFailure(Call<ArtResponse> call, Throwable t) {
                        Toast.makeText(DiscoverActivity.this,
                                "Gagal load data.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void loadChapters() {
        String category = selectedCategories.isEmpty() ? null :
                String.join(",", selectedCategories);
        String genre = selectedGenres.isEmpty() ? null :
                String.join(",", selectedGenres);
        String tag = selectedTags.isEmpty() ? null :
                String.join(",", selectedTags);
        String mood = selectedMoods.isEmpty() ? null :
                String.join(",", selectedMoods);

        artService.getChapterList(currentPage, 20, category, genre, tag, mood,
                        selectedSort, selectedOrder)
                .enqueue(new Callback<ChapterListResponse>() {
                    @Override
                    public void onResponse(Call<ChapterListResponse> call,
                                           Response<ChapterListResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            if (response.body().meta != null) {
                                totalPages = response.body().meta.total_pages;
                            }
                            updatePagination();

                            chapterAdapter = new ChapterListAdapter(DiscoverActivity.this,
                                    response.body().data, chapter -> {
                                Intent intent = new Intent(DiscoverActivity.this,
                                        ChapterReaderActivity.class);
                                intent.putExtra("art_id", chapter.artId);
                                intent.putExtra("chapter_number", chapter.chapterNumber);
                                intent.putExtra("chapter_id", chapter.id);
                                startActivity(intent);
                            });
                            recyclerChapters.setAdapter(chapterAdapter);
                        }
                    }

                    @Override
                    public void onFailure(Call<ChapterListResponse> call, Throwable t) {}
                });
    }

    private void updatePagination() {
        txtPageInfo.setText("Halaman " + currentPage + " / " + totalPages);
        btnPrevPage.setEnabled(currentPage > 1);
        btnNextPage.setEnabled(currentPage < totalPages);
    }
}