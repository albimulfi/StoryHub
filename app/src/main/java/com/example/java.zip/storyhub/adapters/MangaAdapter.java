package com.example.storyhub.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.storyhub.R;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.AnilistResponse;

import java.util.List;

public class MangaAdapter
        extends RecyclerView.Adapter<MangaAdapter.ViewHolder> {

    List<AnilistResponse.Media> mangaList;

    public MangaAdapter(List<AnilistResponse.Media> mangaList) {
        this.mangaList = mangaList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_manga, parent, false);

        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position
    ) {

        AnilistResponse.Media manga =
                mangaList.get(position);

        holder.txtTitle.setText(manga.titleRomaji);

        Glide.with(holder.itemView.getContext())
                .load(RetrofitClient.IMAGE_BASE_URL + manga.coverImage.large)
                .into(holder.imgCover);

    }

    @Override
    public int getItemCount() {
        return mangaList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgCover;
        TextView txtTitle;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgCover =
                    itemView.findViewById(R.id.imgCover);

            txtTitle =
                    itemView.findViewById(R.id.txtTitle);

        }
    }
}