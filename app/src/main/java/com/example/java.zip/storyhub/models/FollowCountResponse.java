package com.example.storyhub.models;

public class FollowCountResponse {
    public int total_follower;    // field langsung, bukan nested
    public int total_following;   // field langsung, bukan nested
}