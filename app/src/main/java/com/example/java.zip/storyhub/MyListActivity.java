package com.example.storyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.storyhub.adapters.MyArtListAdapter;
import com.example.storyhub.adapters.MyChapterListAdapter;
import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.FilterApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.ArtResponse;
import com.example.storyhub.models.ChapterListResponse;
import com.example.storyhub.models.GenreResponse;
import com.example.storyhub.models.MoodResponse;
import com.example.storyhub.models.TagResponse;
import com.example.storyhub.utils.TokenManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyListActivity extends AppCompatActivity {
    LinearLayout navHome, navDiscover, navBookmark, navProfile;

    // tabs
    Button btnTabMyArt, btnTabMyChapter;
    RecyclerView recyclerMyArt, recyclerMyChapter;
    MyArtListAdapter myArtAdapter;
    MyChapterListAdapter myChapterAdapter;

    // kalau belum login (info disuruh login)
    LinearLayout layoutNotLoggedIn;
    Button btnLogin, btnRegister;

    // panel filter
    LinearLayout layoutFilterPanel;
    Button btnOpenFilter, btnApplyFilter, btnResetFilter;

    // filter category
    CheckBox cbBook, cbNovel, cbManhwa, cbManga, cbComic,
            cbGame, cbVisualNovel, cbStoryGame;

    // filter sudah direview user atau belum
    RadioGroup radioReviewStatus;
    RadioButton rbReviewAll, rbReviewSudah, rbReviewBelum;

    // sort
    RadioGroup radioSort, radioOrder;

    // pilihan sort
    RadioButton rbSortTitle, rbSortRatingArt, rbSortReviewersArt,
            rbSortRatingCh, rbSortChapters, rbSortPublished,
            rbSortRatingArtUser, rbSortReviewersArtUser,
            rbSortRatingChUser, rbSortReviewersChUser;
    RadioButton rbOrderAsc, rbOrderDesc;

    // filter name
    com.google.android.flexbox.FlexboxLayout containerFilterGenre,
            containerFilterTag, containerFilterMood;

    // perhalamanan/pagination
    LinearLayout layoutPagination;
    Button btnPrevPage, btnNextPage;
    TextView txtPageInfo;

    // yang dipilih (selected)
    int currentPage = 1;
    int totalPages = 1;
    String currentTab = "art";
    List<String> selectedGenres = new ArrayList<>();
    List<String> selectedTags = new ArrayList<>();
    List<String> selectedMoods = new ArrayList<>();
    List<String> selectedCategories = new ArrayList<>();
    String selectedSort = "title";
    String selectedOrder = "ASC";
    String selectedReviewStatus = "all";
    boolean filterPanelOpen = false;

    TokenManager tokenManager;
    ArtApiService artService;
    FilterApiService filterService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_list);

        tokenManager = new TokenManager(this);
        artService = RetrofitClient.getAuthInstance(tokenManager).create(ArtApiService.class);
        filterService = RetrofitClient.getInstance().create(FilterApiService.class);

        initViews();
        setupNav();
        setupTabs();

        if (tokenManager.isLoggedIn()) {
            layoutNotLoggedIn.setVisibility(View.GONE);
            loadFilterOptions();
            loadMyArtList();
        } else {
            layoutNotLoggedIn.setVisibility(View.VISIBLE);
            layoutFilterPanel.setVisibility(View.GONE);
            recyclerMyArt.setVisibility(View.GONE);
            recyclerMyChapter.setVisibility(View.GONE);
            layoutPagination.setVisibility(View.GONE);
        }
    }

    private void initViews() {
        navHome = findViewById(R.id.navHome);
        navDiscover = findViewById(R.id.navDiscover);
        navBookmark = findViewById(R.id.navBookmark);
        navProfile = findViewById(R.id.navProfile);

        btnTabMyArt = findViewById(R.id.btnTabMyArt);
        btnTabMyChapter = findViewById(R.id.btnTabMyChapter);

        recyclerMyArt = findViewById(R.id.recyclerMyArt);
        recyclerMyArt.setLayoutManager(new LinearLayoutManager(this));

        recyclerMyChapter = findViewById(R.id.recyclerMyChapter);
        recyclerMyChapter.setLayoutManager(new LinearLayoutManager(this));

        layoutNotLoggedIn = findViewById(R.id.layoutNotLoggedIn);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);

        layoutFilterPanel = findViewById(R.id.layoutFilterPanel);
        btnOpenFilter = findViewById(R.id.btnOpenFilter);
        btnApplyFilter = findViewById(R.id.btnApplyFilter);
        btnResetFilter = findViewById(R.id.btnResetFilter);

        cbBook = findViewById(R.id.cbBook);
        cbNovel = findViewById(R.id.cbNovel);
        cbManhwa = findViewById(R.id.cbManhwa);
        cbManga = findViewById(R.id.cbManga);
        cbComic = findViewById(R.id.cbComic);
        cbGame = findViewById(R.id.cbGame);
        cbVisualNovel = findViewById(R.id.cbVisualNovel);
        cbStoryGame = findViewById(R.id.cbStoryGame);

        radioReviewStatus = findViewById(R.id.radioReviewStatus);
        rbReviewAll = findViewById(R.id.rbReviewAll);
        rbReviewSudah = findViewById(R.id.rbReviewSudah);
        rbReviewBelum = findViewById(R.id.rbReviewBelum);

        radioSort = findViewById(R.id.radioSort);
        radioOrder = findViewById(R.id.radioOrder);
        rbSortTitle = findViewById(R.id.rbSortTitle);
        rbSortRatingArt = findViewById(R.id.rbSortRatingArt);
        rbSortReviewersArt = findViewById(R.id.rbSortReviewersArt);
        rbSortRatingCh = findViewById(R.id.rbSortRatingCh);
        rbSortChapters = findViewById(R.id.rbSortChapters);
        rbSortPublished = findViewById(R.id.rbSortPublished);
        rbSortRatingArtUser = findViewById(R.id.rbSortRatingArtUser);
        rbSortReviewersArtUser = findViewById(R.id.rbSortReviewersArtUser);
        rbSortRatingChUser = findViewById(R.id.rbSortRatingChUser);
        rbSortReviewersChUser = findViewById(R.id.rbSortReviewersChUser);
        rbOrderAsc = findViewById(R.id.rbOrderAsc);
        rbOrderDesc = findViewById(R.id.rbOrderDesc);

        containerFilterGenre = findViewById(R.id.containerFilterGenre);
        containerFilterTag = findViewById(R.id.containerFilterTag);
        containerFilterMood = findViewById(R.id.containerFilterMood);

        layoutPagination = findViewById(R.id.layoutPagination);
        btnPrevPage = findViewById(R.id.btnPrevPage);
        btnNextPage = findViewById(R.id.btnNextPage);
        txtPageInfo = findViewById(R.id.txtPageInfo);

        btnLogin.setOnClickListener(v ->
                startActivity(new Intent(this, LoginActivity.class)));
        btnRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));

        btnOpenFilter.setOnClickListener(v -> toggleFilterPanel());

        btnApplyFilter.setOnClickListener(v -> {
            collectFilters();
            currentPage = 1;
            toggleFilterPanel();
            if (currentTab.equals("art")) loadMyArtList();
            else loadMyChapterList();
        });

        btnResetFilter.setOnClickListener(v -> resetFilters());

        btnPrevPage.setOnClickListener(v -> {
            if (currentPage > 1) {
                currentPage--;
                if (currentTab.equals("art")) loadMyArtList();
                else loadMyChapterList();
            }
        });

        btnNextPage.setOnClickListener(v -> {
            if (currentPage < totalPages) {
                currentPage++;
                if (currentTab.equals("art")) loadMyArtList();
                else loadMyChapterList();
            }
        });
    }

    private void toggleFilterPanel() {
        filterPanelOpen = !filterPanelOpen;
        layoutFilterPanel.setVisibility(filterPanelOpen ? View.VISIBLE : View.GONE);
        btnOpenFilter.setText(filterPanelOpen ? "✕ Tutup" : "⚙ Filter & Sort");
    }

    private void setupTabs() {
        btnTabMyArt.setOnClickListener(v -> {
            currentTab = "art";
            currentPage = 1;
            recyclerMyArt.setVisibility(View.VISIBLE);
            recyclerMyChapter.setVisibility(View.GONE);
            btnTabMyArt.setTextColor(getResources().getColor(R.color.primary));
            btnTabMyChapter.setTextColor(getResources().getColor(R.color.black));

            updateSortOptions("art");
            if (tokenManager.isLoggedIn()) loadMyArtList();
        });

        btnTabMyChapter.setOnClickListener(v -> {
            currentTab = "chapter";
            currentPage = 1;
            recyclerMyArt.setVisibility(View.GONE);
            recyclerMyChapter.setVisibility(View.VISIBLE);
            btnTabMyArt.setTextColor(getResources().getColor(R.color.black));
            btnTabMyChapter.setTextColor(getResources().getColor(R.color.primary));
            updateSortOptions("chapter");
            if (tokenManager.isLoggedIn()) loadMyChapterList();
        });
    }

    private void updateSortOptions(String tab) {
        // ngapus sort yang tidak sesuai jenis art/chapter
        if (tab.equals("art")) {
            rbSortChapters.setVisibility(View.VISIBLE);
            rbSortRatingArtUser.setVisibility(View.VISIBLE);
            rbSortReviewersArtUser.setVisibility(View.VISIBLE);
        } else {
            int sortId = radioSort.getCheckedRadioButtonId();
            if (sortId == R.id.rbSortChapters) {
                rbSortTitle.setChecked(true);
                selectedSort = "title";
            }
        }
    }

    private void setupNav() {
        navHome.setOnClickListener(v ->
                startActivity(new Intent(this, HomeActivity.class)));
        navDiscover.setOnClickListener(v ->
                startActivity(new Intent(this, DiscoverActivity.class)));
        navBookmark.setOnClickListener(v ->
                startActivity(new Intent(this, BookmarkActivity.class)));
        navProfile.setOnClickListener(v ->
                startActivity(new Intent(this, ProfileActivity.class)));
    }

    private void loadFilterOptions() {
        filterService.getGenres().enqueue(new Callback<GenreResponse>() {
            @Override
            public void onResponse(Call<GenreResponse> call, Response<GenreResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    buildFilterChips(containerFilterGenre,
                            response.body().data.stream()
                                    .map(g -> g.genre)
                                    .collect(java.util.stream.Collectors.toList()),
                            selectedGenres);
                }
            }
            @Override
            public void onFailure(Call<GenreResponse> call, Throwable t) {}
        });

        filterService.getTags().enqueue(new Callback<TagResponse>() {
            @Override
            public void onResponse(Call<TagResponse> call, Response<TagResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    buildFilterChips(containerFilterTag,
                            response.body().data.stream()
                                    .map(t -> t.tag)
                                    .collect(java.util.stream.Collectors.toList()),
                            selectedTags);
                }
            }
            @Override
            public void onFailure(Call<TagResponse> call, Throwable t) {}
        });

        filterService.getMoods().enqueue(new Callback<MoodResponse>() {
            @Override
            public void onResponse(Call<MoodResponse> call, Response<MoodResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    buildFilterChips(containerFilterMood,
                            response.body().data.stream()
                                    .map(m -> m.mood)
                                    .collect(java.util.stream.Collectors.toList()),
                            selectedMoods);
                }
            }
            @Override
            public void onFailure(Call<MoodResponse> call, Throwable t) {}
        });
    }

    private void buildFilterChips(com.google.android.flexbox.FlexboxLayout container,
                                  List<String> items, List<String> selectedList) {
        runOnUiThread(() -> {
            container.removeAllViews();
            for (String item : items) {
                Button chip = new Button(this);
                chip.setText(item);
                chip.setTextSize(11f);
                chip.setBackgroundResource(R.drawable.chip_background);
                chip.setTextColor(getResources().getColor(R.color.primary));

                com.google.android.flexbox.FlexboxLayout.LayoutParams params =
                        new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT,
                                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 0, 12, 12);
                chip.setLayoutParams(params);

                chip.setOnClickListener(v -> {
                    if (selectedList.contains(item)) {
                        selectedList.remove(item);
                        chip.setBackgroundResource(R.drawable.chip_background);
                        chip.setTextColor(getResources().getColor(R.color.primary));
                    } else {
                        selectedList.add(item);
                        chip.setBackgroundResource(R.drawable.button_gradient);
                        chip.setTextColor(getResources().getColor(R.color.white));
                    }
                });

                container.addView(chip);
            }
        });
    }

    private void collectFilters() {
        selectedCategories.clear();
        if (cbBook.isChecked()) selectedCategories.add("Book");
        if (cbNovel.isChecked()) selectedCategories.add("Novel");
        if (cbManhwa.isChecked()) selectedCategories.add("Manhwa");
        if (cbManga.isChecked()) selectedCategories.add("Manga");
        if (cbComic.isChecked()) selectedCategories.add("Comic");
        if (cbGame.isChecked()) selectedCategories.add("Game");
        if (cbVisualNovel.isChecked()) selectedCategories.add("Visual Novel");
        if (cbStoryGame.isChecked()) selectedCategories.add("Story Game");

        int reviewId = radioReviewStatus.getCheckedRadioButtonId();
        if (reviewId == R.id.rbReviewSudah) selectedReviewStatus = "sudah";
        else if (reviewId == R.id.rbReviewBelum) selectedReviewStatus = "belum";
        else selectedReviewStatus = "all";

        int sortId = radioSort.getCheckedRadioButtonId();
        if (sortId == R.id.rbSortTitle) selectedSort = "title";
        else if (sortId == R.id.rbSortRatingArt) selectedSort = "ratingArt";
        else if (sortId == R.id.rbSortReviewersArt) selectedSort = "reviewersArt";
        else if (sortId == R.id.rbSortRatingCh) selectedSort = "ratingChapter";
        else if (sortId == R.id.rbSortChapters) selectedSort = "chapters";
        else if (sortId == R.id.rbSortPublished) selectedSort = "published";
        else if (sortId == R.id.rbSortRatingArtUser) selectedSort = "ratingArtUser";
        else if (sortId == R.id.rbSortReviewersArtUser) selectedSort = "reviewersArtUser";
        else if (sortId == R.id.rbSortRatingChUser) selectedSort = "ratingChapterUser";
        else if (sortId == R.id.rbSortReviewersChUser) selectedSort = "reviewersChapterUser";

        int orderId = radioOrder.getCheckedRadioButtonId();
        selectedOrder = (orderId == R.id.rbOrderDesc) ? "DESC" : "ASC";
    }

    private void resetFilters() {
        selectedCategories.clear();
        selectedGenres.clear();
        selectedTags.clear();
        selectedMoods.clear();
        selectedSort = "title";
        selectedOrder = "ASC";
        selectedReviewStatus = "all";

        cbBook.setChecked(false); cbNovel.setChecked(false);
        cbManhwa.setChecked(false); cbManga.setChecked(false);
        cbComic.setChecked(false); cbGame.setChecked(false);
        cbVisualNovel.setChecked(false); cbStoryGame.setChecked(false);
        rbReviewAll.setChecked(true);
        rbSortTitle.setChecked(true);
        rbOrderAsc.setChecked(true);

        resetChips(containerFilterGenre);
        resetChips(containerFilterTag);
        resetChips(containerFilterMood);

        currentPage = 1;
        if (currentTab.equals("art")) loadMyArtList();
        else loadMyChapterList();
    }

    private void resetChips(com.google.android.flexbox.FlexboxLayout container) {
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof Button) {
                child.setBackgroundResource(R.drawable.chip_background);
                ((Button) child).setTextColor(getResources().getColor(R.color.primary));
            }
        }
    }

    private void loadMyArtList() {
        String category = selectedCategories.isEmpty() ? null :
                String.join(",", selectedCategories);
        String genre = selectedGenres.isEmpty() ? null :
                String.join(",", selectedGenres);
        String tag = selectedTags.isEmpty() ? null :
                String.join(",", selectedTags);
        String mood = selectedMoods.isEmpty() ? null :
                String.join(",", selectedMoods);
        String sudahDiReview = selectedReviewStatus.equals("sudah") ? "true" :
                selectedReviewStatus.equals("belum") ? "false" : null;

        artService.getArts(currentPage, 20, category, genre, tag, mood,
                        selectedSort, selectedOrder)
                .enqueue(new Callback<ArtResponse>() {
                    @Override
                    public void onResponse(Call<ArtResponse> call,
                                           Response<ArtResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            totalPages = response.body().meta != null ?
                                    response.body().meta.total_pages : 1;
                            updatePagination();

                            myArtAdapter = new MyArtListAdapter(
                                    MyListActivity.this,
                                    response.body().data,
                                    art -> {
                                        Intent intent = new Intent(MyListActivity.this,
                                                DetailContentActivity.class);
                                        intent.putExtra("art_id", art.id);
                                        startActivity(intent);
                                    });
                            recyclerMyArt.setAdapter(myArtAdapter);
                        }
                    }

                    @Override
                    public void onFailure(Call<ArtResponse> call, Throwable t) {
                        Toast.makeText(MyListActivity.this,
                                "Gagal load data.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void loadMyChapterList() {
        String category = selectedCategories.isEmpty() ? null :
                String.join(",", selectedCategories);
        String genre = selectedGenres.isEmpty() ? null :
                String.join(",", selectedGenres);
        String tag = selectedTags.isEmpty() ? null :
                String.join(",", selectedTags);
        String mood = selectedMoods.isEmpty() ? null :
                String.join(",", selectedMoods);

        artService.getChapterList(currentPage, 20, category, genre, tag, mood,
                        selectedSort, selectedOrder)
                .enqueue(new Callback<ChapterListResponse>() {
                    @Override
                    public void onResponse(Call<ChapterListResponse> call,
                                           Response<ChapterListResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            totalPages = response.body().meta != null ?
                                    response.body().meta.total_pages : 1;
                            updatePagination();

                            myChapterAdapter = new MyChapterListAdapter(
                                    MyListActivity.this,
                                    response.body().data,
                                    chapter -> {
                                        Intent intent = new Intent(MyListActivity.this,
                                                ChapterReaderActivity.class);
                                        intent.putExtra("art_id", chapter.artId);
                                        intent.putExtra("chapter_number", chapter.chapterNumber);
                                        intent.putExtra("chapter_id", chapter.id);
                                        startActivity(intent);
                                    });
                            recyclerMyChapter.setAdapter(myChapterAdapter);
                        }
                    }

                    @Override
                    public void onFailure(Call<ChapterListResponse> call, Throwable t) {}
                });
    }

    private void updatePagination() {
        txtPageInfo.setText("Halaman " + currentPage + " / " + totalPages);
        btnPrevPage.setEnabled(currentPage > 1);
        btnNextPage.setEnabled(currentPage < totalPages);
    }
}