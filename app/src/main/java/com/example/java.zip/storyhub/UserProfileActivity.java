package com.example.storyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.storyhub.adapters.ArtAdapter;
import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.api.UserApiService;
import com.example.storyhub.models.ArtResponse;
import com.example.storyhub.models.FollowCountResponse;
import com.example.storyhub.models.IsFollowingResponse;
import com.example.storyhub.models.MessageResponse;
import com.example.storyhub.models.UserResponse;
import com.example.storyhub.utils.TokenManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserProfileActivity extends AppCompatActivity {

    ImageView btnBack, imgProfile;
    TextView txtName, txtUsername, txtBio, txtFollowers, txtFollowing;
    Button btnFollow;
    RecyclerView recyclerArts;

    String username;
    int targetUserId = -1;
    boolean isFollowing = false;

    TokenManager tokenManager;
    UserApiService userService;
    ArtApiService artService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        tokenManager = new TokenManager(this);
        userService = RetrofitClient.getAuthInstance(tokenManager).create(UserApiService.class);
        artService = RetrofitClient.getAuthInstance(tokenManager).create(ArtApiService.class);

        username = getIntent().getStringExtra("username");

        initViews();
        loadUserProfile();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        imgProfile = findViewById(R.id.imgProfile);
        txtName = findViewById(R.id.txtName);
        txtUsername = findViewById(R.id.txtUsername);
        txtBio = findViewById(R.id.txtBio);
        txtFollowers = findViewById(R.id.txtFollowers);
        txtFollowing = findViewById(R.id.txtFollowing);
        btnFollow = findViewById(R.id.btnFollow);
        recyclerArts = findViewById(R.id.recyclerArts);
        recyclerArts.setLayoutManager(new LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL, false));

        btnBack.setOnClickListener(v -> finish());

        if (!tokenManager.isLoggedIn()) {
            btnFollow.setVisibility(View.GONE);
        }

        txtFollowers.setOnClickListener(v -> {
            if (targetUserId == -1) return;
            Intent intent = new Intent(this, FollowListActivity.class);
            intent.putExtra("type", "followers");
            intent.putExtra("user_id", targetUserId);
            startActivity(intent);
        });

        txtFollowing.setOnClickListener(v -> {
            if (targetUserId == -1) return;
            Intent intent = new Intent(this, FollowListActivity.class);
            intent.putExtra("type", "following");
            intent.putExtra("user_id", targetUserId);
            startActivity(intent);
        });

        btnFollow.setOnClickListener(v -> toggleFollow());
    }

    private void loadUserProfile() {
        userService.getUserByUsername(username).enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().user != null) {

                    var user = response.body().user;
                    targetUserId = user.id;

                    txtName.setText(user.name != null ? user.name : user.username);
                    txtUsername.setText("@" + user.username);
                    txtBio.setText(user.bio != null ? user.bio : "");

                    Glide.with(UserProfileActivity.this)
                            .load(RetrofitClient.IMAGE_BASE_URL + user.profileImg)
                            .placeholder(R.drawable.storyhub_logo)
                            .circleCrop()
                            .into(imgProfile);

                    loadFollowCounts();
                    loadUserArts();

                    if (tokenManager.isLoggedIn()
                            && tokenManager.getUserId() != targetUserId) {
                        checkIsFollowing();
                    } else {
                        btnFollow.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {}
        });
    }

    private void loadFollowCounts() {
        userService.getFollowerCount(targetUserId).enqueue(new Callback<FollowCountResponse>() {
            @Override
            public void onResponse(Call<FollowCountResponse> call,
                                   Response<FollowCountResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    txtFollowers.setText(
                            response.body().total_follower + "\nFollowers");
                }
            }
            @Override
            public void onFailure(Call<FollowCountResponse> call, Throwable t) {}
        });

        userService.getFollowingCount(targetUserId).enqueue(new Callback<FollowCountResponse>() {
            @Override
            public void onResponse(Call<FollowCountResponse> call,
                                   Response<FollowCountResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    txtFollowing.setText(
                            response.body().total_following + "\nFollowing");
                }
            }
            @Override
            public void onFailure(Call<FollowCountResponse> call, Throwable t) {}
        });
    }

    private void loadUserArts() {
        artService.getUserArts(username).enqueue(new Callback<ArtResponse>() {
            @Override
            public void onResponse(Call<ArtResponse> call, Response<ArtResponse> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().data != null
                        && !response.body().data.isEmpty()) {

                    ArtAdapter adapter = new ArtAdapter(UserProfileActivity.this,
                            response.body().data, art -> {
                        Intent intent = new Intent(UserProfileActivity.this,
                                DetailContentActivity.class);
                        intent.putExtra("art_id", art.id);
                        startActivity(intent);
                    });
                    recyclerArts.setAdapter(adapter);
                }
            }
            @Override
            public void onFailure(Call<ArtResponse> call, Throwable t) {}
        });
    }

    private void checkIsFollowing() {
        userService.isFollowing(targetUserId).enqueue(new Callback<IsFollowingResponse>() {
            @Override
            public void onResponse(Call<IsFollowingResponse> call,
                                   Response<IsFollowingResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    isFollowing = response.body().isFollowing;
                    boolean isFollower = response.body().isFollower;

                    if (isFollowing) {
                        btnFollow.setText("Unfollow");
                        btnFollow.setBackgroundResource(R.drawable.chip_background);
                        btnFollow.setTextColor(getResources().getColor(R.color.primary));
                    } else if (isFollower) {
                        btnFollow.setText("Follow Back");
                        btnFollow.setBackgroundResource(R.drawable.button_gradient);
                        btnFollow.setTextColor(getResources().getColor(R.color.white));
                    } else {
                        btnFollow.setText("Follow");
                        btnFollow.setBackgroundResource(R.drawable.button_gradient);
                        btnFollow.setTextColor(getResources().getColor(R.color.white));
                    }
                }
            }
            @Override
            public void onFailure(Call<IsFollowingResponse> call, Throwable t) {}
        });
    }

    private void toggleFollow() {
        if (isFollowing) {
            userService.unfollowUser(targetUserId).enqueue(new Callback<MessageResponse>() {
                @Override
                public void onResponse(Call<MessageResponse> call,
                                       Response<MessageResponse> response) {
                    if (response.isSuccessful()) {
                        isFollowing = false;
                        btnFollow.setText("Follow");
                        btnFollow.setBackgroundResource(R.drawable.button_gradient);
                        btnFollow.setTextColor(getResources().getColor(R.color.white));
                        Toast.makeText(UserProfileActivity.this,
                                "Unfollow berhasil.", Toast.LENGTH_SHORT).show();
                        loadFollowCounts();
                    }
                }
                @Override
                public void onFailure(Call<MessageResponse> call, Throwable t) {}
            });
        } else {
            userService.followUser(targetUserId).enqueue(new Callback<MessageResponse>() {
                @Override
                public void onResponse(Call<MessageResponse> call,
                                       Response<MessageResponse> response) {
                    if (response.isSuccessful()) {
                        isFollowing = true;
                        btnFollow.setText("Unfollow");
                        btnFollow.setBackgroundResource(R.drawable.chip_background);
                        btnFollow.setTextColor(getResources().getColor(R.color.primary));
                        Toast.makeText(UserProfileActivity.this,
                                "Follow berhasil!", Toast.LENGTH_SHORT).show();
                        loadFollowCounts();
                    }
                }
                @Override
                public void onFailure(Call<MessageResponse> call, Throwable t) {}
            });
        }
    }
}