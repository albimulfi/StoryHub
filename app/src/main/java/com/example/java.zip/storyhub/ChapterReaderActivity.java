package com.example.storyhub;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.storyhub.adapters.ComicPageAdapter;
import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.Chapter;
import com.example.storyhub.models.ChapterDetailResponse;
import com.example.storyhub.models.ChapterPageResponse;
import com.example.storyhub.models.MessageResponse;
import com.example.storyhub.models.ReadingHistoryRequest;
import com.example.storyhub.utils.TokenManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChapterReaderActivity extends AppCompatActivity {

    ImageView btnBack;
    TextView txtChapterTitle, txtArtTitle, txtNovelContent;
    ScrollView scrollNovel;
    RecyclerView recyclerComicPages;
    LinearLayout layoutLoading;

    int artId, chapterNumber, chapterId;
    boolean isNovel = false;
    TokenManager tokenManager;
    ArtApiService artService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_reader);

        tokenManager = new TokenManager(this);
        artService = RetrofitClient.getAuthInstance(tokenManager).create(ArtApiService.class);

        artId = getIntent().getIntExtra("art_id", -1);
        chapterNumber = getIntent().getIntExtra("chapter_number", 1);
        chapterId = getIntent().getIntExtra("chapter_id", -1);

        if (artId == -1) { finish(); return; }

        initViews();
        loadChapter();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        txtChapterTitle = findViewById(R.id.txtChapterTitle);
        txtArtTitle = findViewById(R.id.txtArtTitle);
        txtNovelContent = findViewById(R.id.txtNovelContent);
        scrollNovel = findViewById(R.id.scrollNovel);
        recyclerComicPages = findViewById(R.id.recyclerComicPages);
        layoutLoading = findViewById(R.id.layoutLoading);

        recyclerComicPages.setLayoutManager(new LinearLayoutManager(this));

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadChapter() {
        layoutLoading.setVisibility(View.VISIBLE);

        artService.getNovelChapter(artId, chapterNumber)
                .enqueue(new Callback<ChapterDetailResponse>() {
                    @Override
                    public void onResponse(Call<ChapterDetailResponse> call,
                                           Response<ChapterDetailResponse> response) {
                        layoutLoading.setVisibility(View.GONE);

                        if (response.isSuccessful() && response.body() != null) {
                            Chapter chapter = response.body().data;
                            isNovel = true;

                            txtChapterTitle.setText("Chapter " + chapter.chapterNumber
                                    + " - " + chapter.title);

                            if (chapter.isiChapterNovel != null) {
                                txtNovelContent.setText(chapter.isiChapterNovel);
                                scrollNovel.setVisibility(View.VISIBLE);
                                recyclerComicPages.setVisibility(View.GONE);
                            }

                            if (tokenManager.isLoggedIn()) {
                                saveReadingHistory(0);

                                // lacak scroll posisi
                                scrollNovel.getViewTreeObserver().addOnScrollChangedListener(() -> {
                                    if (tokenManager.isLoggedIn()) {
                                        int scrollY = scrollNovel.getScrollY();
                                        saveReadingHistory(scrollY);
                                    }
                                });
                            }

                        } else {
                            // kalau bukan novel, ke komik
                            loadComicChapter();
                        }
                    }

                    @Override
                    public void onFailure(Call<ChapterDetailResponse> call, Throwable t) {
                        layoutLoading.setVisibility(View.GONE);
                        loadComicChapter();
                    }
                });
    }

    private void loadComicChapter() {
        layoutLoading.setVisibility(View.VISIBLE);

        artService.getComicChapter(artId, chapterNumber)
                .enqueue(new Callback<ChapterPageResponse>() {
                    @Override
                    public void onResponse(Call<ChapterPageResponse> call,
                                           Response<ChapterPageResponse> response) {
                        layoutLoading.setVisibility(View.GONE);

                        if (response.isSuccessful() && response.body() != null
                                && response.body().data != null) {
                            isNovel = false;
                            scrollNovel.setVisibility(View.GONE);
                            recyclerComicPages.setVisibility(View.VISIBLE);

                            ComicPageAdapter adapter = new ComicPageAdapter(
                                    ChapterReaderActivity.this,
                                    response.body().data);
                            recyclerComicPages.setAdapter(adapter);

                            if (tokenManager.isLoggedIn()) {
                                saveReadingHistory(0);

                                // lacak scroll posisi
                                scrollNovel.getViewTreeObserver().addOnScrollChangedListener(() -> {
                                    if (tokenManager.isLoggedIn()) {
                                        int scrollY = scrollNovel.getScrollY();
                                        saveReadingHistory(scrollY);
                                    }
                                });
                            }
                        } else {
                            Toast.makeText(ChapterReaderActivity.this,
                                    "Chapter tidak ditemukan.", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }

                    @Override
                    public void onFailure(Call<ChapterPageResponse> call, Throwable t) {
                        layoutLoading.setVisibility(View.GONE);
                        Toast.makeText(ChapterReaderActivity.this,
                                "Gagal load chapter.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private boolean historySaved = false;
    private long lastSaveTime = 0;

    private void saveReadingHistory(int scrollY) {
        long now = System.currentTimeMillis();
        if (historySaved && now - lastSaveTime < 3000) return;
        lastSaveTime = now;

        ReadingHistoryRequest request = new ReadingHistoryRequest(1, scrollY);

        if (!historySaved) {
            historySaved = true;
            artService.postReadingHistory(artId, chapterId, request)
                    .enqueue(new Callback<MessageResponse>() {
                        @Override
                        public void onResponse(Call<MessageResponse> call,
                                               Response<MessageResponse> response) {}
                        @Override
                        public void onFailure(Call<MessageResponse> call, Throwable t) {}
                    });
        } else {
            artService.updateReadingHistory(artId, chapterId, request)
                    .enqueue(new Callback<MessageResponse>() {
                        @Override
                        public void onResponse(Call<MessageResponse> call,
                                               Response<MessageResponse> response) {}
                        @Override
                        public void onFailure(Call<MessageResponse> call, Throwable t) {}
                    });
        }
    }
}