package com.example.storyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.storyhub.adapters.EditChapterAdapter;
import com.example.storyhub.api.ArtApiService;
import com.example.storyhub.api.RetrofitClient;
import com.example.storyhub.models.ArtDetailResponse;
import com.example.storyhub.models.Chapter;
import com.example.storyhub.models.ChapterResponse;
import com.example.storyhub.models.CreateArtRequest;
import com.example.storyhub.models.CreateArtResponse;
import com.example.storyhub.models.MessageResponse;
import com.example.storyhub.utils.TokenManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditNovelActivity extends AppCompatActivity {

    ImageView btnBack;
    EditText etTitle, etTagline, etSynopsis, etCoverImg, etBannerImg;
    Spinner spinnerStatus;
    Button btnSave, btnDelete;
    ProgressBar progressBar;
    RecyclerView recyclerChapters;
    TextView txtNovelTitle;
    LinearLayout layoutLoading;

    int artId;
    String artTitle;
    TokenManager tokenManager;
    ArtApiService artService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_novel);

        tokenManager = new TokenManager(this);
        artService = RetrofitClient.getAuthInstance(tokenManager)
                .create(ArtApiService.class);

        artId = getIntent().getIntExtra("art_id", -1);
        artTitle = getIntent().getStringExtra("art_title");

        if (artId == -1) { finish(); return; }

        initViews();
        loadArtDetail();
        loadChapters();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        etTitle = findViewById(R.id.etTitle);
        etTagline = findViewById(R.id.etTagline);
        etSynopsis = findViewById(R.id.etSynopsis);
        etCoverImg = findViewById(R.id.etCoverImg);
        etBannerImg = findViewById(R.id.etBannerImg);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        btnSave = findViewById(R.id.btnSave);
        btnDelete = findViewById(R.id.btnDelete);
        progressBar = findViewById(R.id.progressBar);
        recyclerChapters = findViewById(R.id.recyclerChapters);
        txtNovelTitle = findViewById(R.id.txtNovelTitle);
        layoutLoading = findViewById(R.id.layoutLoading);

        recyclerChapters.setLayoutManager(new LinearLayoutManager(this));
        recyclerChapters.setNestedScrollingEnabled(false);

        String[] statusOptions = {"Ongoing", "Completed", "Hiatus"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, statusOptions);
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);

        if (artTitle != null) txtNovelTitle.setText(artTitle);

        btnBack.setOnClickListener(v -> finish());
        btnSave.setOnClickListener(v -> saveNovel());
        btnDelete.setOnClickListener(v -> confirmDelete());
    }

    private void loadArtDetail() {
        layoutLoading.setVisibility(View.VISIBLE);

        artService.getArtById(artId).enqueue(new Callback<ArtDetailResponse>() {
            @Override
            public void onResponse(Call<ArtDetailResponse> call,
                                   Response<ArtDetailResponse> response) {
                layoutLoading.setVisibility(View.GONE);

                if (response.isSuccessful() && response.body() != null
                        && response.body().data != null) {

                    var art = response.body().data;

                    etTitle.setText(art.title);
                    etTagline.setText(art.tagline);
                    etSynopsis.setText(art.synopsis);
                    etCoverImg.setText(art.coverImg);
                    etBannerImg.setText(art.bannerImg);
                    txtNovelTitle.setText(art.title);

                    String[] statuses = {"Ongoing", "Completed", "Hiatus"};
                    for (int i = 0; i < statuses.length; i++) {
                        if (statuses[i].equals(art.status)) {
                            spinnerStatus.setSelection(i);
                            break;
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ArtDetailResponse> call, Throwable t) {
                layoutLoading.setVisibility(View.GONE);
            }
        });
    }

    private void loadChapters() {
        artService.getChapters(artId).enqueue(new Callback<ChapterResponse>() {
            @Override
            public void onResponse(Call<ChapterResponse> call,
                                   Response<ChapterResponse> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().data != null) {

                    EditChapterAdapter adapter = new EditChapterAdapter(
                            EditNovelActivity.this,
                            response.body().data,
                            chapter -> {
                                Intent intent = new Intent(EditNovelActivity.this,
                                        EditChapterActivity.class);
                                intent.putExtra("art_id", artId);
                                intent.putExtra("chapter_id", chapter.id);
                                intent.putExtra("chapter_number", chapter.chapterNumber);
                                intent.putExtra("chapter_title", chapter.title);
                                startActivity(intent);
                            },
                            chapter -> {
                                confirmDeleteChapter(chapter);
                            }
                    );
                    recyclerChapters.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<ChapterResponse> call, Throwable t) {}
        });
    }

    private void saveNovel() {
        String title = etTitle.getText().toString().trim();
        String tagline = etTagline.getText().toString().trim();
        String synopsis = etSynopsis.getText().toString().trim();
        String coverImg = etCoverImg.getText().toString().trim();
        String bannerImg = etBannerImg.getText().toString().trim();
        String status = spinnerStatus.getSelectedItem().toString();

        if (title.isEmpty() || tagline.isEmpty() || synopsis.isEmpty()
                || coverImg.isEmpty() || bannerImg.isEmpty()) {
            Toast.makeText(this, "Semua field harus diisi.", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnSave.setEnabled(false);

        CreateArtRequest request = new CreateArtRequest(
                "Published", title, coverImg, bannerImg,
                status, "Novel", tagline, synopsis
        );

        artService.updateArt(artId, request).enqueue(new Callback<CreateArtResponse>() {
            @Override
            public void onResponse(Call<CreateArtResponse> call,
                                   Response<CreateArtResponse> response) {
                progressBar.setVisibility(View.GONE);
                btnSave.setEnabled(true);

                if (response.isSuccessful()) {
                    Toast.makeText(EditNovelActivity.this,
                            "Novel berhasil diupdate!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(EditNovelActivity.this,
                            "Gagal update novel.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CreateArtResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                btnSave.setEnabled(true);
                Toast.makeText(EditNovelActivity.this,
                        "Gagal terhubung ke server.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Novel")
                .setMessage("Yakin ingin menghapus novel ini? Semua chapter akan terhapus.")
                .setPositiveButton("Hapus", (dialog, which) -> deleteNovel())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void deleteNovel() {
        progressBar.setVisibility(View.VISIBLE);

        artService.deleteArt(artId).enqueue(new Callback<MessageResponse>() {
            @Override
            public void onResponse(Call<MessageResponse> call,
                                   Response<MessageResponse> response) {
                progressBar.setVisibility(View.GONE);

                if (response.isSuccessful()) {
                    Toast.makeText(EditNovelActivity.this,
                            "Novel berhasil dihapus.", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(EditNovelActivity.this,
                            "Gagal hapus novel.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MessageResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void confirmDeleteChapter(Chapter chapter) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Chapter")
                .setMessage("Hapus Chapter " + chapter.chapterNumber + "?")
                .setPositiveButton("Hapus", (dialog, which) -> {
                    artService.deleteChapter(artId, chapter.id)
                            .enqueue(new Callback<MessageResponse>() {
                                @Override
                                public void onResponse(Call<MessageResponse> call,
                                                       Response<MessageResponse> response) {
                                    if (response.isSuccessful()) {
                                        Toast.makeText(EditNovelActivity.this,
                                                "Chapter dihapus.", Toast.LENGTH_SHORT).show();
                                        loadChapters();
                                    }
                                }

                                @Override
                                public void onFailure(Call<MessageResponse> call,
                                                      Throwable t) {}
                            });
                })
                .setNegativeButton("Batal", null)
                .show();
    }
}