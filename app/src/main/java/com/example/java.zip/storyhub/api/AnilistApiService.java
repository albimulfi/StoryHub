package com.example.storyhub.api;

import com.example.storyhub.models.AnilistResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface AnilistApiService {

    @Headers("Content-Type: application/json")
    @POST("/")
    Call<AnilistResponse> getTrendingManga(
            @Body String query
    );

}